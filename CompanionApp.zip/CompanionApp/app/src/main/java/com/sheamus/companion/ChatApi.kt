package com.sheamus.companion

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object ChatApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS) // streaming: no read timeout
        .build()

    private val JSON = "application/json".toMediaType()
    private const val OPENROUTER = "https://openrouter.ai/api/v1"

    private fun base(url: String) = url.trim().trimEnd('/')

    private fun httpError(code: Int, body: String?): IOException {
        val detail = body?.take(300).orEmpty()
        return IOException("HTTP $code${if (detail.isNotBlank()) ": $detail" else ""}")
    }

    suspend fun listOllama(url: String): List<ModelOption> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("${base(url)}/api/tags").build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) throw httpError(res.code, res.body?.string())
            val arr = JSONObject(res.body!!.string()).optJSONArray("models") ?: JSONArray()
            (0 until arr.length())
                .map { arr.getJSONObject(it).getString("name") }
                .sorted()
                .map { ModelOption(Provider.OLLAMA, it) }
        }
    }

    suspend fun listOpenRouter(key: String): List<ModelOption> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$OPENROUTER/models").apply {
            if (key.isNotBlank()) header("Authorization", "Bearer $key")
        }.build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) throw httpError(res.code, res.body?.string())
            val arr = JSONObject(res.body!!.string()).optJSONArray("data") ?: JSONArray()
            (0 until arr.length())
                .map { arr.getJSONObject(it).getString("id") }
                .sorted()
                .map { ModelOption(Provider.OPENROUTER, it) }
        }
    }

    /** Streams the assistant reply as text chunks. */
    fun stream(
        provider: Provider,
        ollamaUrl: String,
        openRouterKey: String,
        model: String,
        messages: List<Msg>
    ): Flow<String> = flow {
        val body = JSONObject()
            .put("model", model)
            .put("messages", messages.toJsonArray())
            .put("stream", true)
            .toString()
            .toRequestBody(JSON)

        val req = when (provider) {
            Provider.OLLAMA -> Request.Builder()
                .url("${base(ollamaUrl)}/api/chat")
                .post(body)
                .build()

            Provider.OPENROUTER -> Request.Builder()
                .url("$OPENROUTER/chat/completions")
                .header("Authorization", "Bearer $openRouterKey")
                .header("X-Title", "Companion")
                .post(body)
                .build()
        }

        val call = client.newCall(req)
        currentCoroutineContext()[Job]?.invokeOnCompletion { call.cancel() }

        call.execute().use { res ->
            if (!res.isSuccessful) throw httpError(res.code, res.body?.string())
            val source = res.body!!.source()
            while (true) {
                val line = source.readUtf8Line() ?: break
                if (line.isBlank()) continue
                when (provider) {
                    Provider.OLLAMA -> {
                        val o = JSONObject(line)
                        o.optString("error").takeIf { it.isNotBlank() }?.let { throw IOException(it) }
                        val text = o.optJSONObject("message")?.optString("content").orEmpty()
                        if (text.isNotEmpty()) emit(text)
                        if (o.optBoolean("done")) break
                    }

                    Provider.OPENROUTER -> {
                        if (!line.startsWith("data:")) continue // skips ": OPENROUTER PROCESSING" keepalives
                        val data = line.removePrefix("data:").trim()
                        if (data == "[DONE]") break
                        val o = JSONObject(data)
                        o.optJSONObject("error")?.let { throw IOException(it.optString("message", "OpenRouter error")) }
                        val choices = o.optJSONArray("choices") ?: continue
                        if (choices.length() == 0) continue
                        val text = choices.getJSONObject(0)
                            .optJSONObject("delta")?.optString("content").orEmpty()
                        if (text.isNotEmpty() && text != "null") emit(text)
                    }
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}
