package com.sheamus.companion

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var personas by mutableStateOf(store.loadPersonas())
        private set
    var selectedId by mutableStateOf("")
        private set
    var messages by mutableStateOf<List<Msg>>(emptyList())
        private set
    var models by mutableStateOf<List<ModelOption>>(emptyList())
        private set
    var loadingModels by mutableStateOf(false)
        private set
    var streaming by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
    var modelNotice by mutableStateOf<String?>(null)
        private set

    var ollamaUrl by mutableStateOf(store.ollamaUrl)
        private set
    var openRouterKey by mutableStateOf(store.openRouterKey)
        private set

    private var job: Job? = null

    val current: Persona
        get() = personas.firstOrNull { it.id == selectedId } ?: personas.first()

    init {
        selectedId = store.selectedPersonaId.takeIf { id -> personas.any { it.id == id } }
            ?: personas.first().id
        messages = store.loadHistory(selectedId)
        refreshModels()
    }

    fun refreshModels() {
        viewModelScope.launch {
            loadingModels = true
            modelNotice = null
            val notes = mutableListOf<String>()
            val all = mutableListOf<ModelOption>()
            if (ollamaUrl.isNotBlank()) {
                runCatching { ChatApi.listOllama(ollamaUrl) }
                    .onSuccess { all += it }
                    .onFailure { notes += "Ollama: ${it.message ?: "unreachable"}" }
            }
            runCatching { ChatApi.listOpenRouter(openRouterKey) }
                .onSuccess { all += it }
                .onFailure { notes += "OpenRouter: ${it.message ?: "unreachable"}" }
            models = all
            modelNotice = notes.takeIf { it.isNotEmpty() }?.joinToString("\n")
            loadingModels = false
        }
    }

    fun saveSettings(url: String, key: String) {
        store.ollamaUrl = url
        store.openRouterKey = key
        ollamaUrl = store.ollamaUrl
        openRouterKey = store.openRouterKey
        refreshModels()
    }

    fun selectPersona(id: String) {
        if (id == selectedId) return
        stop()
        selectedId = id
        store.selectedPersonaId = id
        messages = store.loadHistory(id)
        error = null
    }

    fun upsertPersona(p: Persona) {
        personas = if (personas.any { it.id == p.id }) {
            personas.map { if (it.id == p.id) p else it }
        } else {
            personas + p
        }
        store.savePersonas(personas)
    }

    fun deletePersona(id: String) {
        if (personas.size <= 1) return
        stop()
        store.deleteHistory(id)
        personas = personas.filterNot { it.id == id }
        store.savePersonas(personas)
        if (selectedId == id) selectPersonaForce(personas.first().id)
    }

    private fun selectPersonaForce(id: String) {
        selectedId = id
        store.selectedPersonaId = id
        messages = store.loadHistory(id)
    }

    fun setModel(option: ModelOption) {
        upsertPersona(current.copy(provider = option.provider, modelId = option.id))
    }

    fun clearChat() {
        stop()
        messages = emptyList()
        store.deleteHistory(selectedId)
        error = null
    }

    fun stop() {
        job?.cancel()
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || streaming) return
        val persona = current
        if (persona.modelId.isBlank()) {
            error = "Pick a model first (tap the model name at the top)."
            return
        }
        if (persona.provider == Provider.OPENROUTER && openRouterKey.isBlank()) {
            error = "Add your OpenRouter key in Settings."
            return
        }
        error = null

        val history = messages + Msg("user", trimmed)
        messages = history + Msg("assistant", "")
        val personaId = persona.id

        val payload = buildList {
            if (persona.systemPrompt.isNotBlank()) add(Msg("system", persona.systemPrompt))
            addAll(history)
        }

        streaming = true
        job = viewModelScope.launch {
            try {
                ChatApi.stream(persona.provider, ollamaUrl, openRouterKey, persona.modelId, payload)
                    .collect { chunk ->
                        if (selectedId == personaId) {
                            val last = messages.last()
                            messages = messages.dropLast(1) + last.copy(content = last.content + chunk)
                        }
                    }
            } catch (e: CancellationException) {
                // stopped by user
            } catch (e: Exception) {
                error = e.message ?: "Request failed"
            } finally {
                streaming = false
                if (selectedId == personaId) {
                    // drop an empty assistant bubble if nothing came back
                    if (messages.lastOrNull()?.let { it.role == "assistant" && it.content.isBlank() } == true) {
                        messages = messages.dropLast(1)
                    }
                    store.saveHistory(personaId, messages)
                }
            }
        }
    }
}
