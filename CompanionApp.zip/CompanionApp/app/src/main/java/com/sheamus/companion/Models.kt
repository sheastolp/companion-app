package com.sheamus.companion

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class Provider(val label: String) {
    OLLAMA("Ollama"),
    OPENROUTER("OpenRouter")
}

data class Msg(val role: String, val content: String)

data class ModelOption(val provider: Provider, val id: String)

data class Persona(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val systemPrompt: String,
    val provider: Provider = Provider.OLLAMA,
    val modelId: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("systemPrompt", systemPrompt)
        .put("provider", provider.name)
        .put("modelId", modelId)

    companion object {
        fun fromJson(o: JSONObject) = Persona(
            id = o.getString("id"),
            name = o.getString("name"),
            systemPrompt = o.optString("systemPrompt"),
            provider = runCatching { Provider.valueOf(o.optString("provider")) }
                .getOrDefault(Provider.OLLAMA),
            modelId = o.optString("modelId")
        )

        fun default() = Persona(
            name = "Buddy",
            systemPrompt = "You are Buddy, a warm, witty and supportive AI companion. " +
                "Chat casually, remember what the user tells you in this conversation, " +
                "and keep replies fairly short unless asked for more."
        )
    }
}

fun List<Msg>.toJsonArray(): JSONArray {
    val arr = JSONArray()
    forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
    return arr
}

fun JSONArray.toMsgs(): List<Msg> =
    (0 until length()).map {
        val o = getJSONObject(it)
        Msg(o.getString("role"), o.getString("content"))
    }
