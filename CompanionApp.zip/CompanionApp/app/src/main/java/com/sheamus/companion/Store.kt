package com.sheamus.companion

import android.content.Context
import org.json.JSONArray
import java.io.File

class Store(private val context: Context) {
    private val prefs = context.getSharedPreferences("companion", Context.MODE_PRIVATE)

    var ollamaUrl: String
        get() = prefs.getString("ollamaUrl", "http://192.168.1.100:11434") ?: ""
        set(v) = prefs.edit().putString("ollamaUrl", v.trim()).apply()

    var openRouterKey: String
        get() = prefs.getString("openRouterKey", "") ?: ""
        set(v) = prefs.edit().putString("openRouterKey", v.trim()).apply()

    var selectedPersonaId: String
        get() = prefs.getString("selectedPersonaId", "") ?: ""
        set(v) = prefs.edit().putString("selectedPersonaId", v).apply()

    fun loadPersonas(): List<Persona> {
        val raw = prefs.getString("personas", null)
        if (raw.isNullOrBlank()) return listOf(Persona.default())
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { Persona.fromJson(arr.getJSONObject(it)) }
        }.getOrNull()?.takeIf { it.isNotEmpty() } ?: listOf(Persona.default())
    }

    fun savePersonas(list: List<Persona>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("personas", arr.toString()).apply()
    }

    private fun historyFile(personaId: String) = File(context.filesDir, "chat_$personaId.json")

    fun loadHistory(personaId: String): List<Msg> {
        val f = historyFile(personaId)
        if (!f.exists()) return emptyList()
        return runCatching { JSONArray(f.readText()).toMsgs() }.getOrDefault(emptyList())
    }

    fun saveHistory(personaId: String, msgs: List<Msg>) {
        runCatching { historyFile(personaId).writeText(msgs.toJsonArray().toString()) }
    }

    fun deleteHistory(personaId: String) {
        historyFile(personaId).delete()
    }
}
