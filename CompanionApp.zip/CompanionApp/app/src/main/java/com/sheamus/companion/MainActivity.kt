package com.sheamus.companion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.isSystemInDarkTheme
import android.os.Build

private enum class Screen { CHAT, PERSONAS, SETTINGS }

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            val ctx = LocalContext.current
            val scheme = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                    if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(vm)
                }
            }
        }
    }
}

@Composable
private fun App(vm: ChatViewModel) {
    var screen by remember { mutableStateOf(Screen.CHAT) }
    when (screen) {
        Screen.CHAT -> ChatScreen(
            vm,
            onPersonas = { screen = Screen.PERSONAS },
            onSettings = { screen = Screen.SETTINGS }
        )
        Screen.PERSONAS -> PersonasScreen(vm, onBack = { screen = Screen.CHAT })
        Screen.SETTINGS -> SettingsScreen(vm, onBack = { screen = Screen.CHAT })
    }
}

// ---------------------------------------------------------------- Chat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScreen(vm: ChatViewModel, onPersonas: () -> Unit, onSettings: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var showPicker by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val persona = vm.current

    val lastLen = vm.messages.lastOrNull()?.content?.length ?: 0
    LaunchedEffect(vm.messages.size, lastLen) {
        if (vm.messages.isNotEmpty()) listState.scrollToItem(vm.messages.lastIndex)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(persona.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(
                            text = if (persona.modelId.isBlank()) "Tap to pick a model"
                            else "${persona.provider.label} · ${persona.modelId}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.clickable { showPicker = true }
                        )
                    }
                },
                actions = {
                    TextButton(onClick = { showPicker = true }) { Text("Model") }
                    Box {
                        TextButton(onClick = { menuOpen = true }) { Text("⋮") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Companions") },
                                onClick = { menuOpen = false; onPersonas() })
                            DropdownMenuItem(text = { Text("Settings") },
                                onClick = { menuOpen = false; onSettings() })
                            DropdownMenuItem(text = { Text("Clear chat") },
                                onClick = { menuOpen = false; confirmClear = true })
                        }
                    }
                }
            )
        },
        bottomBar = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                vm.error?.let {
                    Text(
                        it,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Message ${persona.name}") },
                        maxLines = 5,
                        shape = RoundedCornerShape(24.dp)
                    )
                    if (vm.streaming) {
                        Button(onClick = { vm.stop() }) { Text("Stop") }
                    } else {
                        Button(
                            onClick = { vm.send(input); input = "" },
                            enabled = input.isNotBlank()
                        ) { Text("Send") }
                    }
                }
            }
        }
    ) { pad ->
        if (vm.messages.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text(
                    "Say hi to ${persona.name} 👋",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(pad),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.messages) { m -> Bubble(m, vm.streaming && m === vm.messages.last()) }
            }
        }
    }

    if (showPicker) {
        ModelPicker(vm, onDismiss = { showPicker = false })
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear chat with ${persona.name}?") },
            text = { Text("This deletes the saved conversation.") },
            confirmButton = {
                TextButton(onClick = { vm.clearChat(); confirmClear = false }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Bubble(m: Msg, typing: Boolean) {
    val mine = m.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (mine) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            SelectionContainer {
                Text(
                    text = if (m.content.isEmpty() && typing) "…" else m.content,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Model picker

@Composable
private fun ModelPicker(vm: ChatViewModel, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<Provider?>(null) }
    var manual by remember { mutableStateOf("") }
    val persona = vm.current

    val shown = vm.models.filter {
        (filter == null || it.provider == filter) &&
            it.id.contains(query.trim(), ignoreCase = true)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose a model") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { filter = null }) {
                        Text("All", fontWeight = if (filter == null) FontWeight.Bold else FontWeight.Normal)
                    }
                    Provider.values().forEach { p ->
                        TextButton(onClick = { filter = p }) {
                            Text(p.label, fontWeight = if (filter == p) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Search models") },
                    modifier = Modifier.fillMaxWidth()
                )
                vm.modelNotice?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                if (vm.loadingModels) {
                    Text("Loading…", Modifier.padding(top = 8.dp))
                }
                LazyColumn(Modifier.heightIn(max = 340.dp).padding(top = 8.dp)) {
                    items(shown) { opt ->
                        val selected = opt.provider == persona.provider && opt.id == persona.modelId
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable { vm.setModel(opt); onDismiss() }
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                opt.id,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                opt.provider.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        HorizontalDivider()
                    }
                }
                if (!vm.loadingModels && shown.isEmpty()) {
                    Text(
                        "No models found. Check Settings, or type a model id below.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                Row(
                    Modifier.padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = manual,
                        onValueChange = { manual = it },
                        singleLine = true,
                        placeholder = { Text("Custom model id") },
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        enabled = manual.isNotBlank(),
                        onClick = {
                            vm.setModel(ModelOption(filter ?: persona.provider, manual.trim()))
                            onDismiss()
                        }
                    ) { Text("Use") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.refreshModels() }) { Text("Refresh") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

// ---------------------------------------------------------------- Personas

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PersonasScreen(vm: ChatViewModel, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<Persona?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Companions") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = {
                    TextButton(onClick = {
                        editing = Persona(name = "", systemPrompt = "")
                    }) { Text("New") }
                }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad)) {
            items(vm.personas) { p ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.selectPersona(p.id); onBack() }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            p.name,
                            fontWeight = if (p.id == vm.selectedId) FontWeight.Bold else FontWeight.Normal,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            if (p.modelId.isBlank()) "No model chosen" else "${p.provider.label} · ${p.modelId}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    TextButton(onClick = { editing = p }) { Text("Edit") }
                }
                HorizontalDivider()
            }
        }
    }

    editing?.let { p ->
        var name by remember(p.id) { mutableStateOf(p.name) }
        var prompt by remember(p.id) { mutableStateOf(p.systemPrompt) }
        val exists = vm.personas.any { it.id == p.id }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(if (exists) "Edit companion" else "New companion") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("Name") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = prompt, onValueChange = { prompt = it },
                        label = { Text("Personality / system prompt") },
                        minLines = 4, maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (exists && vm.personas.size > 1) {
                        TextButton(onClick = { vm.deletePersona(p.id); editing = null }) {
                            Text("Delete companion", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = {
                        vm.upsertPersona(p.copy(name = name.trim(), systemPrompt = prompt.trim()))
                        if (!exists) vm.selectPersona(p.id)
                        editing = null
                    }
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- Settings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    var url by remember { mutableStateOf(vm.ollamaUrl) }
    var key by remember { mutableStateOf(vm.openRouterKey) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                label = { Text("Ollama address") },
                supportingText = { Text("e.g. http://100.x.y.z:11434 (Tailscale IP) or your LAN IP. Leave blank to skip Ollama.") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = key, onValueChange = { key = it },
                label = { Text("OpenRouter API key") },
                visualTransformation = PasswordVisualTransformation(),
                supportingText = { Text("From openrouter.ai/keys. Stored only on this phone.") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { vm.saveSettings(url, key); onBack() }) { Text("Save & refresh models") }
            Spacer(Modifier.padding(4.dp))
            Text(
                "Ollama must listen on your network: set OLLAMA_HOST=0.0.0.0 on the PC and allow port 11434 through the firewall.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
