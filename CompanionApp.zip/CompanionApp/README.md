# Companion

Android AI companion chat with a model picker. Models come from your own Ollama server
(over LAN/Tailscale) and/or OpenRouter (cloud), listed together in one picker.

## Build
1. Open this folder in Android Studio (Koala or newer). It will generate the Gradle wrapper and sync.
2. Run on a device or build an APK: Build > Build APK(s).

## First run
1. Menu (⋮) > Settings
   - Ollama address, e.g. `http://100.x.y.z:11434` (Tailscale IP of your PC/laptop)
   - OpenRouter API key (optional, from openrouter.ai/keys)
2. Tap **Model** at the top and pick one. The choice is saved per companion.
3. Menu > Companions to add more characters, each with its own personality and model.

## Ollama server notes
- Set `OLLAMA_HOST=0.0.0.0` so the phone can reach it, then restart Ollama.
- Allow port 11434 through the firewall (or just use Tailscale).

## Notes
- Chat history is stored per companion on the device; the API key never leaves it except in requests to OpenRouter.
- Cleartext HTTP is enabled so plain `http://` Ollama addresses work.
